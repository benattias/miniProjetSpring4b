package com.souad.joueurs.service;


import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.souad.joueurs.dto.JoueurDTO;
import com.souad.joueurs.entities.Equipe;
import com.souad.joueurs.entities.Joueur;
import com.souad.joueurs.repos.EquipeRepository;
import com.souad.joueurs.repos.JoueurRepository;

@Service
public class JoueurServiceImpl implements JoueurService {
@Autowired
JoueurRepository joueurRepository;
@Autowired
EquipeRepository equipeRepository;
@Autowired
ModelMapper modelMapper;
@Override
public JoueurDTO saveJoueur(JoueurDTO p) {
 return convertEntityToDto( joueurRepository.save(convertDtoToEntity(p)));
}
@Override
public JoueurDTO updateJoueur(JoueurDTO p) {
 return convertEntityToDto(joueurRepository.save(convertDtoToEntity(p)));
}

@Override
public JoueurDTO getJoueur(Long id) {
return convertEntityToDto( joueurRepository.findById(id).get());
}
@Override
public List<JoueurDTO> getAllJoueurs() {

return joueurRepository.findAll().stream()
.map(this::convertEntityToDto)
.collect(Collectors.toList());}



@Override
public void deleteJoueur(Joueur j) {
	joueurRepository.delete(j);
}
 @Override
public void  deleteJoueurById(Long id) {
	 joueurRepository.deleteById(id);
}

@Override
public Page<Joueur> getAllJoueursParPage(int page, int size) {
return joueurRepository.findAll(PageRequest.of(page, size));
}

@Override
public List<Joueur> findByNomJoueur(String nom) {
return joueurRepository.findByNomJoueur(nom);
}
@Override
public List<Joueur> findByNomJoueurLike(String nom) {
	return joueurRepository.findByNomJoueurContains(nom);
}

@Override
public List<Joueur> findByNomPrenom(String nom, String prenom) {

return joueurRepository.findByNomPrenom(nom,prenom);
}
@Override
public List<Joueur> findByEquipe(Equipe equipe) {
return joueurRepository.findByEquipe(equipe);
}
@Override
public List<Joueur> findByEquipeIdEq(Long id) {
return joueurRepository.findByEquipeIdEq(id);
}
@Override
public List<Joueur> findByOrderByNomJoueurAsc() {
return joueurRepository.findByOrderByNomJoueurAsc();
}
@Override
public List<Joueur> trierJoueursNomsPrenom() {
return joueurRepository.trierJoueursNomsPrenom();
}
@Override
public List<Equipe> getAllEquipes() {
	return equipeRepository.findAll();
}

@Override
public JoueurDTO convertEntityToDto(Joueur joueur) {
	
	modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.LOOSE);
	JoueurDTO joueurDTO = modelMapper.map(joueur, JoueurDTO.class);

 return joueurDTO;
 }

@Override
public Joueur convertDtoToEntity(JoueurDTO joueurDto) {
	Joueur joueur = new Joueur();
	joueur = modelMapper.map(joueurDto, Joueur.class);

//	joueur.setIdJoueur(joueurDto.getIdJoueur());
//	joueur.setNomJoueur(joueurDto.getNomJoueur());
//joueur.setPrenomJoueur(joueurDto.getPrenomJoueur());
//joueur.setDateNaissance(joueurDto.getDateNaissance());
//joueur.setEquipe(joueurDto.getEquipe());
 return joueur;
}
}