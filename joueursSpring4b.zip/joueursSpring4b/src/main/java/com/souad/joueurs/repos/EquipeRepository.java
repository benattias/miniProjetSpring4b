package com.souad.joueurs.repos;
import org.springframework.data.jpa.repository.JpaRepository;

import com.souad.joueurs.entities.Equipe;


public interface EquipeRepository extends JpaRepository<Equipe, Long> {

}