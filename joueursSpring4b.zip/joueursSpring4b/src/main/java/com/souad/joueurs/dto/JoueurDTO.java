package com.souad.joueurs.dto;

import java.util.Date;

import com.souad.joueurs.entities.Equipe;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class JoueurDTO {
private Long idJoueur;
private String nomJoueur;
private String prenomJoueur;
private Date dateNaissance;
private Equipe equipe;
private String nomEq;
}